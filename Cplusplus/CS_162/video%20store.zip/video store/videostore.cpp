#define _CRT_SECURE_NO_DEPRECATE

/**
* videostore.cpp
* a simple program to manage a collection of videos. 
* Note: Only add/list functionalities are implemented. The rest of the functionalities are left for your exercise.
* Written By: Li Liang
* Date: 06/22/2006
* Source: None
**/

#include <iostream>
#include <iomanip>
using namespace std;

//maximum number of chars in the strings
const int MAX_LEN = 101;

//video store capacity
const int STORE_CAPACITY = 100;

//declare the category data type
enum Category {action, comedy, drama, nCategory};

//convert category to meaningful description
void convertCategory(Category category, char description[]);

//declare the Video data type
struct Video
{
	char title[MAX_LEN];
	Category category;
	int quantity;
};

//user interaction functions
void displayMenu();
char getCommand();
void completeTask(char command, Video videoList[], int& size);
void addVideo(Video videoList[], int& size);

//read in video information functions
void getVideo(Video & aVideo);
void getTitle(char title[]);
Category getCategory();
int getQuantity();

//database manipulation functions
void addVideo(const Video& aVideo, Video videoList[], int& size);
void listVideos(Video videoList[], int size);

//tools to read in strings and integers
void readString(char prompt[], char str[]);
int readInteger(char prompt[]);

/**
* main: the driver
**/
int main()
{
	char command;
	Video videoList[STORE_CAPACITY];
	int size = 0;

	cout << "\nWelcome to Cute Video!\n" << endl;

	displayMenu();
	command = getCommand();
	while(command != 'q')
	{
		completeTask(command, videoList, size);
		displayMenu();
		command = getCommand();
	}

	cout << "\nThank you for using Cute Video\n" << endl;

	return 0;
}

/**
* displayMenu: display the main menu to user
* in: none
* out: none
* return: none
**/
void displayMenu()
{
	cout << endl 
		<< "\ta. add a video" << endl
		<< "\tl. list all the videos" << endl
		<< "\tq. exit" << endl 
		<< endl;
}

/**
* getCommand: read in user's command
* in: none
* out: none
* return: the command in lower case
**/
char getCommand()
{
	char option;

	cout << "Please enter the command (a, l, or q): ";
	cin >> option;
	cin.ignore(100, '\n'); //remove any left over chars

	return tolower(option);
}

/**
* completeTask: execute user's command
* in: command
* in/out: videoList
* in/out: size
* return: none
**/
void completeTask(char command, Video videoList[], int& size)
{
	switch (command)
	{
	case 'a': addVideo(videoList, size);
		break;
	case 'l': listVideos(videoList, size);
		break;
	default: cout << "Illegal Command!" << endl;
		break;
	}
}

/**
* addVideo: read in video object and add it to the database
* in/out: videoList
* in/out: size
* return: none
**/
void addVideo(Video videoList[], int& size)
{
	Video aVideo;

	getVideo(aVideo);
	addVideo(aVideo, videoList, size);
}

/**
* addVideo: add the video object to the database
* in: aVideo
* in/out: videoList
* in/out: size
* return: none
**/
void addVideo(const Video& aVideo, Video videoList[], int& size)
{
	//append the video object to the end of the array
	videoList[size] = aVideo;
	size = size + 1;
}

/**
* listVideos: list all the videos in the database
* in: videoList
* in: size
* return: none
**/
void listVideos(Video videoList[], int size)
{
	//step through the array and display each video object
	int i;
	char categoryDescription[MAX_LEN];

    //display header of the table
	cout << setw(40) << "TITLE" << setw(20) << "CATEGORY" << setw(10) << "QUANTITY" << endl;
	for(i=0; i<size; i++)
	{
		convertCategory(videoList[i].category, categoryDescription); 
		cout << setw(40) << videoList[i].title 
			<< setw(20) << categoryDescription
			<< setw(10) << videoList[i].quantity << endl;
	}
}

/**
* getVideo: read in a video object
* in: none
* out: aVideo 
* return: none
**/
void getVideo(Video & aVideo)
{
	getTitle(aVideo.title);
	aVideo.category = getCategory();
	aVideo.quantity = getQuantity();
}

/**
* getTitle: read in the title of a video
* in: none
* out: title
* return: none
**/
void getTitle(char title[])
{
	readString("\nPlease enter the title of the video: ", title);
}

/**
* getCategory: read in the category of a video
* in: none
* out: none
* return: category
**/
Category getCategory()
{
	int temp;
	temp = readInteger("\nPlease enter the category of the video\n(0 for action, 1 for comedy, 2 for drama): ");
	return static_cast <Category> (temp);
}

/**
* getQuantity: read in the quantity of a video
* in: none
* out: none
* return: quantity
**/
int getQuantity()
{
	return readInteger("\nPlease enter the quantity of the video: ");
}

/**
* readString: read in a string
* in: prompt
* out: str
* return: none
**/
void readString(char prompt[], char str[])
{
	cout << prompt;
	cin.get (str, MAX_LEN);
	cin.ignore(100, '\n');
}

/**
* readInteger: read in an integer
* in: prompt
* out: none
* return: an integer
**/
int readInteger(char prompt[])
{
	int temp;

	cout << prompt;
	cin >> temp;
	while(!cin)
	{
		//clear the error code of cin
		cin.clear();

		//remove the garbage on the input stream
		cin.ignore(100, '\n');

		//ask user to try again
		cout << "Illegal integer! Try again: ";

		//read in
		cin >> temp;
	}

	//remove the '\n'
	cin.ignore(100, '\n');

	return temp;
}
/**
* convertCategory: convert category to meaningful description
* in: category
* out: categoryDescription
* return: none
**/
void convertCategory(Category category, char categoryDescription[])
{
	switch (category)
	{
	case action: strcpy(categoryDescription, "action");
		break;
	case comedy: strcpy(categoryDescription, "comedy");
		break;
	case drama: strcpy(categoryDescription, "drama");
		break;
	default: strcpy(categoryDescription, "illgal category");
		break;
	}
}
