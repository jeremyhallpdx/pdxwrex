#ifndef VIDEOSTORE_H
#define VIDEOSTORE_H
#include <iostream>
#include <iomanip>
#include "tools.h"
using namespace std;

//maximum number of chars in the strings
const int MAX_LEN = 101;

//video store capacity
const int STORE_CAPACITY = 100;

//declare the category data type
enum Category {action, comedy, drama, nCategory};

//convert category to meaningful description
void convertCategory(Category category, char description[]);

//declare the Video data type
struct Video
{
	char title[MAX_LEN];
	Category category;
	int quantity;
};

//database manipulation functions
void addVideo(const Video& aVideo, Video videoList[], int& size);
void listVideos(Video videoList[], int size);



#endif