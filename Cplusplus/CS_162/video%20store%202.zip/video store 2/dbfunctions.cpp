#include "videostore.h"
/**
* addVideo: add the video object to the database
* in: aVideo
* in/out: videoList
* in/out: size
* return: none
**/
void addVideo(const Video& aVideo, Video videoList[], int& size)
{
	//append the video object to the end of the array
	videoList[size] = aVideo;
	size = size + 1;
}

/**
* listVideos: list all the videos in the database
* in: videoList
* in: size
* return: none
**/
void listVideos(Video videoList[], int size)
{
	//step through the array and display each video object
	int i;
	char categoryDescription[MAX_LEN];

    //display header of the table
	cout << setw(40) << "TITLE" << setw(20) << "CATEGORY" << setw(10) << "QUANTITY" << endl;
	for(i=0; i<size; i++)
	{
		convertCategory(videoList[i].category, categoryDescription); 
		cout << setw(40) << videoList[i].title 
			<< setw(20) << categoryDescription
			<< setw(10) << videoList[i].quantity << endl;
	}
}