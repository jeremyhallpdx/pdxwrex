#ifndef TOOLS_H
#define TOOLS_H

//tools to read in strings and integers
void readString(char prompt[], char str[], int maxLen);
int readInteger(char prompt[]);

#endif