#include <iostream>
using namespace std;

#include "tools.h"
/**
* readString: read in a string
* in: prompt
* in: maxLen
* out: str
* return: none
**/
void readString(char prompt[], char str[], int maxLen)
{
	cout << prompt;
	cin.get (str, maxLen);
	cin.ignore(100, '\n');
}

/**
* readInteger: read in an integer
* in: prompt
* out: none
* return: an integer
**/
int readInteger(char prompt[])
{
	int temp;

	cout << prompt;
	cin >> temp;
	while(!cin)
	{
		//clear the error code of cin
		cin.clear();

		//remove the garbage on the input stream
		cin.ignore(100, '\n');

		//ask user to try again
		cout << "Illegal integer! Try again: ";

		//read in
		cin >> temp;
	}

	//remove the '\n'
	cin.ignore(100, '\n');

	return temp;
}