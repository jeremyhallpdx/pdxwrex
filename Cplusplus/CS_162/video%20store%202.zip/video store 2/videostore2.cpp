#define _CRT_SECURE_NO_DEPRECATE

/**
* videostore.cpp
* a simple program to manage a collection of videos. 
* Note: Only add/list functionalities are implemented. The rest of the functionalities are left for your exercise.
* Written By: Li Liang
* Date: 06/22/2006
* Source: None
**/

#include "videostore.h"

//user interaction functions
void displayMenu();
char getCommand();
void completeTask(char command, Video videoList[], int& size);
void addVideo(Video videoList[], int& size);

//read in video information functions
void getVideo(Video & aVideo);
void getTitle(char title[]);
Category getCategory();
int getQuantity();

/**
* main: the driver
**/
int main()
{
	char command;
	Video videoList[STORE_CAPACITY];
	int size = 0;

	cout << "\nWelcome to Cute Video!\n" << endl;

	displayMenu();
	command = getCommand();
	while(command != 'q')
	{
		completeTask(command, videoList, size);
		displayMenu();
		command = getCommand();
	}

	cout << "\nThank you for using Cute Video\n" << endl;
	return 0;
}

/**
* displayMenu: display the main menu to user
* in: none
* out: none
* return: none
**/
void displayMenu()
{
	cout << endl 
		<< "\ta. add a video" << endl
		<< "\tl. list all the videos" << endl
		<< "\tq. exit" << endl 
		<< endl;
}

/**
* getCommand: read in user's command
* in: none
* out: none
* return: the command in lower case
**/
char getCommand()
{
	char option;

	cout << "Please enter the command (a, l, or q): ";
	cin >> option;
	cin.ignore(100, '\n'); //remove any left over chars

	return tolower(option);
}

/**
* completeTask: execute user's command
* in: command
* in/out: videoList
* in/out: size
* return: none
**/
void completeTask(char command, Video videoList[], int& size)
{
	switch (command)
	{
	case 'a': addVideo(videoList, size);
		break;
	case 'l': listVideos(videoList, size);
		break;
	default: cout << "Illegal Command!" << endl;
		break;
	}
}

/**
* addVideo: read in video object and add it to the database
* in/out: videoList
* in/out: size
* return: none
**/
void addVideo(Video videoList[], int& size)
{
	Video aVideo;

	getVideo(aVideo);
	addVideo(aVideo, videoList, size);
}



/**
* getVideo: read in a video object
* in: none
* out: aVideo 
* return: none
**/
void getVideo(Video & aVideo)
{
	getTitle(aVideo.title);
	aVideo.category = getCategory();
	aVideo.quantity = getQuantity();
}

/**
* getTitle: read in the title of a video
* in: none
* out: title
* return: none
**/
void getTitle(char title[])
{
	readString("\nPlease enter the title of the video: ", title, MAX_LEN);
}

/**
* getCategory: read in the category of a video
* in: none
* out: none
* return: category
**/
Category getCategory()
{
	int temp;
	temp = readInteger("\nPlease enter the category of the video\n(0 for action, 1 for comedy, 2 for drama): ");
	return static_cast <Category> (temp);
}

#define _CRT_SECURE_NO_DEPRECATE

#include <cstring>

/**
* getQuantity: read in the quantity of a video
* in: none
* out: none
* return: quantity
**/
int getQuantity()
{
	return readInteger("\nPlease enter the quantity of the video: ");
}


/**
* convertCategory: convert category to meaningful description
* in: category
* out: categoryDescription
* return: none
**/
void convertCategory(Category category, char categoryDescription[])
{
	switch (category)
	{
	case action: strcpy(categoryDescription, "action");
		break;
	case comedy: strcpy(categoryDescription, "comedy");
		break;
	case drama: strcpy(categoryDescription, "drama");
		break;
	default: strcpy(categoryDescription, "illgal category");
		break;
	}
}
